package com.example.dadsprogram;
//импорт библиотек
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
//создание переменных
public class MainActivity extends AppCompatActivity {
private TextView showfot;
private TextView showndfl;
private TextView showfotview;
private TextView showpfr;
private TextView showfss;
private TextView showns;
private TextView showoms;
private TextView showitog;
private EditText zarplata;
private Button mButton;
private double ndfl;
private double zarplataplus;
private double pfr, pfrgotov;
private double oms, omsgotov;
private double fss, fssgotov;
private double ns, nsgotov;
private double itog, itoggotov;
private double ndflgotov;


   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showfotview = findViewById(R.id.ndfshowlView);
        showndfl = findViewById(R.id.ndflView);
        showoms = findViewById(R.id.omsView);
        showitog = findViewById(R.id.itogView5);
        showpfr = findViewById(R.id.pfrView);
        showfot = findViewById(R.id.fotView);
        zarplata  =  findViewById(R.id.zarplata);
        showfss = findViewById(R.id.fssView);
        showns = findViewById(R.id.nsView);
        mButton = findViewById(R.id.button);
    }
}
